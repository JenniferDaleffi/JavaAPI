package br.com.fiap.model;

public class Planeta {

	private String name;
	private String rotation_period;
	private String orbital_period;
	private String diamater;
	private String climate;
	private String terrain;

	public Planeta() {
		super();
	}

	public Planeta(String name, String rotation_period, String orbital_period, String diamater, String climate,
			String terrain) {
		super();
		this.name = name;
		this.rotation_period = rotation_period;
		this.orbital_period = orbital_period;
		this.diamater = diamater;
		this.climate = climate;
		this.terrain = terrain;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRotation_period() {
		return rotation_period;
	}

	public void setRotation_period(String rotation_period) {
		this.rotation_period = rotation_period;
	}

	public String getOrbital_period() {
		return orbital_period;
	}

	public void setOrbital_period(String orbital_period) {
		this.orbital_period = orbital_period;
	}

	public String getDiamater() {
		return diamater;
	}

	public void setDiamater(String diamater) {
		this.diamater = diamater;
	}

	public String getClimate() {
		return climate;
	}

	public void setClimate(String climate) {
		this.climate = climate;
	}

	public String getTerrain() {
		return terrain;
	}

	public void setTerrain(String terrain) {
		this.terrain = terrain;
	}

	@Override
	public String toString() {
		return "Planeta [name=" + name + ", rotation_period=" + rotation_period + ", orbital_period=" + orbital_period
				+ ", diamater=" + diamater + ", climate=" + climate + ", terrain=" + terrain + "]";
	}

}
