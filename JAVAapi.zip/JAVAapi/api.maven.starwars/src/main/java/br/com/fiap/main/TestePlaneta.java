package br.com.fiap.main;

import java.io.IOException;

import javax.swing.JOptionPane;

import org.apache.http.client.ClientProtocolException;

import br.com.fiap.model.Planeta;
import br.com.fiap.service.PlanetaService;

public class TestePlaneta {

	static String texto(String j) {
		return JOptionPane.showInputDialog(j);
	}

	public static void main(String[] args) throws ClientProtocolException, IOException {

		PlanetaService planetaServic = new PlanetaService();

		String p = texto("Digite o numero do Planeta");

		Planeta planeta = planetaServic.getPlaneta(p);
				

	}

}
